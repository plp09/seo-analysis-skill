# SEO Technical Audit Skill

基于 13 维度评分体系的 SEO 技术审计技能，输出中文 PDF 报告。

## 文件说明

- `SKILL.md` — 技能总规范（必读）
- `references/scoring_criteria.md` — 13 维度评分标准
- `scripts/seo_crawl.py` — 网站抓取脚本（输出 JSON）
- `scripts/seo_report_pdf.py` — 中文 PDF 报告生成器
- `scripts/seo_report_html.py` — HTML 报告生成器（可选）

## 本地安装

将整个目录放入 `~/.qclaw/skills/seo-analysis/` 即可使用。

## 社区安装

```bash
npx skills add 你的GitHub用户名/seo-analysis-skill
```

## 审核维度

1. Title 质量（权重 1.1）
2. Meta Description（权重 1.0）
3. H1/H2 结构（权重 0.9）
4. 图片 Alt 覆盖（权重 0.8）
5. hreflang 多语言（权重 1.0）
6. Open Graph（权重 0.8）
7. Sitemap 质量（权重 0.9）
8. 社交分享（权重 0.7）
9. 技术安全性（权重 1.2）
10. GEO/AI 内容与结构（权重 2.6）
11. B2B 外贸关键词覆盖（权重 1.4）
12. PAA 内容覆盖（权重 1.4）
13. 综合评分与修复方案

## 使用方法

1. 抓取数据：`python3 seo_crawl.py https://目标网站.com/`
2. 生成报告：`python3 seo_report_pdf.py data.json --title "网站名 SEO 报告"`
